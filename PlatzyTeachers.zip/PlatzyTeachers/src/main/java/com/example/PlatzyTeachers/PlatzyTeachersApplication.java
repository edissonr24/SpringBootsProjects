package com.example.PlatzyTeachers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlatzyTeachersApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlatzyTeachersApplication.class, args);
	}

}
